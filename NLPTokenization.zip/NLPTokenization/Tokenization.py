import  nltk
#nltk.download()
from  nltk.stem import  PorterStemmer
from  nltk.corpus import  stopwords

paragraph = " Networking is hard. There are various moving parts involved and many factors need to be considered to make it work. Fortunately, a number of open-source libraries have emerged over time to make networking easier. AFNetworking, created and maintained by the people of Gowalla, is one such library. This tutorial will introduce you to the AFNetworking framework while also showing how to query the iTunes Store API!"


sentences = nltk.sent_tokenize(paragraph)
#print(sentences)
#print((nltk.word_tokenize(paragraph)))

stemmer = PorterStemmer()

for i in  range(len(sentences)):
    words = nltk.word_tokenize(sentences[i])
    words = [ stemmer.stem(word) for word in words if word not in set(stopwords.words('english'))]
    sentences[i] = ' '.join(words)
    print(sentences[i])